SPENDLY - installable phone app (PWA)

1. Upload this whole folder to any HTTPS host (free options: GitHub Pages, Netlify Drop, Cloudflare Pages).
2. Open the link on your phone.
   Android (Chrome): menu > Install app / Add to Home screen.
   iPhone (Safari): Share > Add to Home Screen.
3. Spendly then opens full-screen from your home screen with its own icon and works offline.

Want a real .apk? Paste your hosted link into pwabuilder.com and choose Android.
Your expenses are stored on the phone itself; use Settings > "View / copy my data as CSV" as a backup.
